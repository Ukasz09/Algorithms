package allExercises.stacks;


public interface IStack<T> {

    /* Wyjatki */

    class EmptyStackException extends Exception {
    }

    class FullStackException extends Exception {
    }

    /* Metody */

    boolean isEmpty();

    boolean isFull();

    T pop() throws EmptyStackException;

    void push(T elem) throws FullStackException;

    int size();

    T top() throws EmptyStackException;
}
