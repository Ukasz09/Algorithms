package allExercises.stacks;

import allExercises.lists.AbstractList;
import allExercises.lists.TwoWayCycledListWithSentinel;

public class ListStack<T> implements IStack<T> {

    TwoWayCycledListWithSentinel<T> _list;

    /* KONSTRUKTOR */

    public ListStack() {
        _list = new TwoWayCycledListWithSentinel<>();
    }

    /* GETTERY */

    public TwoWayCycledListWithSentinel<T> get_list() {
        return _list;
    }

    /* METODY */

    @Override
    public boolean isEmpty() {
        return _list.isEmpty();
    }

    @Override
    public boolean isFull() {
        return false;
    }

    @Override
    public T pop() throws EmptyStackException {

        if(this.isEmpty())
            throw new EmptyStackException();

        T value = _list.delete(0);
        return value;
    }

    @Override
    public void push(T elem){
        _list.add(0, elem);
    }

    @Override
    public int size() {
        return _list.size();
    }

    @Override
    public T top() throws EmptyStackException {

        if(this.isEmpty())
            throw new EmptyStackException();

        T value = _list.get(0);
        return value;
    }

    @Override
    public String toString() {

        StringBuffer buffer = new StringBuffer();
        buffer.append('[');

        if (!isEmpty()) {

            for (T item : _list)
                buffer.append(item).append(", ");

            buffer.setLength(buffer.length() - 2);
        }
        buffer.append(']');
        return buffer.toString();
    }
}
