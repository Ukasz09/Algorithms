package allExercises.objects;

public class Car {

    Make make;
    String model;
    double age;

    /* ENUMERATOR MARKI */
    public enum Make {
        OPEL, CHEVROLET, AUDI, PORSCH, FIAT, LAMBORGHINI, BUGATTI, CITROEN
    }

    /* KONSTRUKTORY */

    public Car() {

        this(Make.OPEL, "Astra", 10);
    }

    public Car(Make make, String model, double age) {

        this.make = make;
        this.model = model;
        this.age = age;
    }

    /* GETTERY / SETTERY */

    public Make getMake() {
        return make;
    }

    public String getModel() {
        return model;
    }

    public double getAge() {
        return age;
    }

    public void setMake(Make make) {
        this.make = make;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public void setAge(double age) {
        this.age = age;
    }

    /* METODY */

    @Override
    public String toString() {

        return (make + " " + model + " " + age);
    }

    @Override
    public boolean equals(Object obj) {

        Car tmpCar = (Car) obj;

        if (this.make.equals(tmpCar.make) && this.model.equals(tmpCar.model) && this.age == tmpCar.getAge())
            return true;

        return false;
    }
}
