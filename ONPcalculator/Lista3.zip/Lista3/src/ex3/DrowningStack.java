package ex3;

import allExercises.stacks.ListStack;

public class DrowningStack<T> extends ListStack<T> {

    private final static int DEFAULT_STACK_SIZE = 10;
    private int stackSize;

    /* KONSTRUKTORY */

    public DrowningStack(int N) {
        super();

        if (N > 0)
            stackSize = N;
        else stackSize = DEFAULT_STACK_SIZE;
    }

    public DrowningStack() {
        stackSize = DEFAULT_STACK_SIZE;
    }

    /* METODY */

    @Override
    public void push(T elem) {

        if (size() >= stackSize)
            get_list().deleteLastIndex();

        get_list().add(0, elem);

    }

}
