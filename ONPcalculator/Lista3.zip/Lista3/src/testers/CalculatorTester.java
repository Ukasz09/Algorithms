package testers;

import ex2.CalculatorONP;

public class CalculatorTester {

    public static void main(String[] args) {

        double calcResult;

        calcResult = CalculatorONP.calculate("4 6 + 2 / 8 -2 + +"); //(4 + 6) / 2 + (8 + -2)
        System.out.println(calcResult);

        calcResult = CalculatorONP.calculate("14 4 - 2 / 2 -"); //(14 - 4) / 2 - 2
        System.out.println(calcResult);

        calcResult = CalculatorONP.calculate("6 4 * 2 *"); //6 * 4 * 2
        System.out.println(calcResult);

        calcResult = CalculatorONP.calculate("27 3 sqrt"); // pierwiastek 3 stopnia z 27 + 4^3
        System.out.println(calcResult);

        calcResult = CalculatorONP.calculate("16 2 sqrt"); // sqrt(16)
        System.out.println(calcResult);

        calcResult = CalculatorONP.calculate("0 4 log"); // log o podstawie 4 z 64
        System.out.println(calcResult);
    }

}
