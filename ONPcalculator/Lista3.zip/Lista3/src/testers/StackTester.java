package testers;

import allExercises.objects.Car;
import allExercises.stacks.IStack;
import allExercises.stacks.ListStack;

public class StackTester {

    public static void main(String[] args) {

        ListStack listStack = new ListStack();

        System.out.println("Czy pusty: " + listStack.isEmpty());
        System.out.println(listStack);

        //usuniecie elementu
        try {

            listStack.pop();
        } catch (IStack.EmptyStackException e) {
            System.out.println("Nie mozna wykonac. Stos jest pusty");
        }

        //dodanie elementu na stos

        listStack.push(new Car());
        listStack.push(new Car(Car.Make.FIAT, "Jakies", 10));
        listStack.push(new Car(Car.Make.AUDI, "Zafira", 2));
        listStack.push(new Car(Car.Make.CHEVROLET, "Jakis", 100));
        listStack.push(new Car(Car.Make.BUGATTI, "Veyronn", 91));

        System.out.println(listStack);

        try {

            listStack.pop();
            listStack.pop();

        } catch (IStack.EmptyStackException e) {
            System.out.println("Nie mozna wykonac. Stos jest pusty");
        }

        System.out.println(listStack);
    }

}
