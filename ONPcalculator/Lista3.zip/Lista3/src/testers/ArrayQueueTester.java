package testers;

import allExercises.objects.Car;
import allExercises.queues.IQueue;
import ex1.ArrayQueue;

public class ArrayQueueTester {

    public static void main(String[] args) {

        ArrayQueue queueEx1 = new ArrayQueue(3);

        /* ___________________________________________________________________________________*/
        /* Sprawdzenie pelnosci kolejki i test wyswietlenia elementow na pustej kolejce */

        System.out.println("Czy kolejka jest pusta: " + queueEx1.isEmpty());
        System.out.println(queueEx1);

        /* ___________________________________________________________________________________*/
        /* Dodanie elementow do kolejki */

        System.out.println("\n\nKolejka pelna: " + queueEx1.isFull());

        try {

            queueEx1.enqueue(new Car());
            queueEx1.enqueue(new Car(Car.Make.FIAT, "Jakies", 10));
            queueEx1.enqueue(new Car(Car.Make.AUDI, "Zafira", 2));
            queueEx1.enqueue(new Car(Car.Make.CHEVROLET, "Jakis", 100));
            queueEx1.enqueue(new Car(Car.Make.BUGATTI, "Veyronn", 91));

        } catch (IQueue.FullQueueException e) {
            System.out.println("Nie dodano. Kolejka pelna ");
        }

        System.out.println("Kolejka pelna: " + queueEx1.isFull());
        System.out.println(queueEx1);
        System.out.println("Wielkosc kolejki: " + queueEx1.size());

        /* ___________________________________________________________________________________*/
        /* Pobranie pierwszego elementu, usuniecie z kolejki */

        //wypisanie pierwszego elementu
        try {

            System.out.println("\n\nPierwszy element kolejki: " + queueEx1.first());
        } catch (IQueue.EmptyQueueException e) {
            System.out.println("\n\nNie mozna pobrac. Kolejka pusta");
        }

        //test usuniecia
        try {

            queueEx1.dequeue();
            queueEx1.dequeue();
            queueEx1.dequeue();
        } catch (IQueue.EmptyQueueException e) {
            System.out.println("Nie mozna usunac elementu - kolejka jest pusta");
        }

        System.out.println("Kolejka po modyfikacji: " + queueEx1);
        System.out.println("Wielkosc kolejki: " + queueEx1.size());

        //test usuniecia na pustej kolejce
        try {
            queueEx1.dequeue();
            queueEx1.dequeue();

        } catch (IQueue.EmptyQueueException e) {

            System.out.println("Nie mozna usunac elementu - kolejka jest pusta");
        }

        System.out.println("Stan kolejki po usunieciach: " + queueEx1);
        System.out.println("Wielkosc kolejki: " + queueEx1.size());
    }
}
