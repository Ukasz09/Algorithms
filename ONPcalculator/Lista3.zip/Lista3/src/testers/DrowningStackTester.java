package testers;

import allExercises.objects.Car;
import ex3.DrowningStack;

public class DrowningStackTester {

    public static void main(String[] args){
        DrowningStack drowningStack = new DrowningStack(6);

        drowningStack.push(new Car());
        drowningStack.push(new Car(Car.Make.FIAT, "Jakies", 10));
        drowningStack.push(new Car(Car.Make.AUDI, "Zafira", 2));
        drowningStack.push(new Car(Car.Make.CHEVROLET, "Jakis", 100));
        drowningStack.push(new Car(Car.Make.BUGATTI, "Veyronn", 91));
        drowningStack.push(new Car(Car.Make.CITROEN, "Picasso", 11));

        System.out.println(drowningStack);
    }

}
