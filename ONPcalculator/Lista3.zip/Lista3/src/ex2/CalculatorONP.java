package ex2;

import allExercises.stacks.IStack;
import allExercises.stacks.ListStack;

import java.util.ArrayList;

public abstract class CalculatorONP {

    /* METODY */

    private static void divideStringToWords(String textLine, ArrayList inputsElements) {

        inputsElements.clear();
        String tmpElement = "";

        for (int i = 0; i < textLine.length(); i++) {

            if (textLine.charAt(i) == ' ') {

                inputsElements.add(tmpElement);
                tmpElement = "";

            } else tmpElement += textLine.charAt(i);

        }

        if (!tmpElement.equals(" ")) {
            inputsElements.add(tmpElement);
        }

    }

    private static boolean wordIsNumber(String word) {

        try {
            Double.parseDouble(word);
        } catch (NumberFormatException e) {
            return false;
        }

        return true;
    }

    private static double doOperation(String operation, double lastVal, double preLastVal) {

        switch (operation) {

            case "+":
                return preLastVal + lastVal;
            case "-":
                return preLastVal - lastVal;
            case "*":
                return preLastVal * lastVal;
            case "/": {

                if (lastVal == 0) {

                    System.out.println("Dzielenie przez 0");
                    throw new IllegalArgumentException();
                }

                return preLastVal / lastVal;
            }

            case "^":
                return Math.pow(preLastVal, lastVal);

            case "sqrt":
                return Math.pow(preLastVal, 1 / lastVal);

            case "log": {

                //lastVal - podstawa log
                //preLastVal - wartosc log do obliczenia

                double value = Math.log(preLastVal) / Math.log(lastVal);
                return value;
            }

            default:
                throw new IllegalArgumentException();
        }

    }

    public static double calculate(String input) {

        ArrayList<String> inputsElements = new ArrayList<>();
        ListStack<Double> listStack = new ListStack<>();

        divideStringToWords(input, inputsElements);

        double lastElem;
        double preLastElem;
        double resultOfOperation;

        for (String elem : inputsElements) {

            if (wordIsNumber(elem))
                listStack.push(Double.parseDouble(elem));
            else {

                //sciagniecie dwoch ostatnich wartosci ze stosu i wrzucenie ich do zmiennych

                try {
                    lastElem = listStack.pop();
                    preLastElem = listStack.pop();
                } catch (IStack.EmptyStackException e) {

                    throw new IllegalArgumentException();
                }

                //wykonanie odpowiedniej operacji

                resultOfOperation = doOperation(elem, lastElem, preLastElem);

                //wrzucenie waetosci na stos
                listStack.push(resultOfOperation);

            }
        } //zamyka for'a

        double retVal;

        try {

            retVal = listStack.pop();

        } catch (IStack.EmptyStackException e) {

            throw new IllegalArgumentException();
        }

        return retVal;
    }
}
